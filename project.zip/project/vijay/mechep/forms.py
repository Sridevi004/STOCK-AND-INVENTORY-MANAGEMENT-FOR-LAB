from django import forms
from .models import MechepEquip
from datetime import date

class MechepEquipForm(forms.ModelForm):
    class Meta:
        model = MechepEquip
        fields = ['name', 'count', 'expiry_date']
        widgets = {
            'expiry_date': forms.DateInput(attrs={'type': 'date'}),
        }

    def clean_expiry_date(self):
        expiry_date = self.cleaned_data.get('expiry_date')
        if expiry_date and expiry_date < date.today():
            raise forms.ValidationError("Expiry date cannot be in the past.")
        return expiry_date
