from django.shortcuts import render, redirect, get_object_or_404
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from django.contrib import messages
from .models import MechepEquip
from .forms import MechepEquipForm
from datetime import date

def mechep_home(request):
    return render(request, 'mechep_home.html')

def mechep_add_equipment(request):
    if request.method == 'POST':
        form = MechepEquipForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            count = form.cleaned_data.get('count')
            expiry_date = form.cleaned_data.get('expiry_date')

            if count is None:
                form.add_error('count', 'Count cannot be empty.')
                return render(request, 'mechep_add.html', {'form': form})

            # Check if equipment exists
            equipment, created = MechepEquip.objects.get_or_create(
                name=name,
                defaults={'count': count, 'expiry_date': expiry_date}
            )

            if not created:
                equipment.count += count
                if expiry_date:
                    equipment.expiry_date = expiry_date
            else:
                equipment.count = count
                equipment.expiry_date = expiry_date

            equipment.save()
            return redirect('mechep_view_equipments')
        else:
            print("Form errors:", form.errors)
    else:
        form = MechepEquipForm()
    return render(request, 'mechep_add.html', {'form': form})


def mechep_view_equipments(request):
    equipments = MechepEquip.objects.all()
    today = timezone.now().date()

    for equipment in equipments:
        if equipment.expiry_date:
            days = (equipment.expiry_date - today).days
            equipment.days_left = days

            if days > 0:
                equipment.extra_label = f"{days} days"
            elif days == 0:
                equipment.extra_label = "Expiring today"
                send_mail(
                    subject=f"Expiry Alert: {equipment.name}",
                    message=f"The equipment '{equipment.name}' is expiring today ({equipment.expiry_date}).",
                    from_email=settings.DEFAULT_FROM_EMAIL,
                    recipient_list=[settings.ADMIN_EMAIL],
                    fail_silently=False,
                )
            else:
                equipment.extra_label = f"Expired {abs(days)} days ago"
        else:
            equipment.extra_label = "No expiry date"

    return render(request, 'mechep_view.html', {'equipments': equipments})


def mechep_damage(request, id):
    equipment = get_object_or_404(MechepEquip, id=id)
    if request.method == 'POST':
        equipment.count -= 1
        equipment.save()
        return redirect('mechep_view_equipments')
    return redirect('mechep_view_equipments')


def mechep_request_equipment(request, id):
    equipment = get_object_or_404(MechepEquip, id=id)

    if request.method == 'POST':
        user_info = ""
        if request.user.is_authenticated:
            user_info = f"\n\nRequested by: {request.user.username} ({request.user.email})"

        send_mail(
            subject=f"Request for Equipment: {equipment.name}",
            message=f"The user has requested:\n\nName: {equipment.name}\nCount: {equipment.count}{user_info}",
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=['admin@example.com'],  # Replace with real email
            fail_silently=False,
        )
        messages.success(request, "Request sent successfully.")
        return redirect('mechep_view_equipments')

    return render(request, 'mechep_view.html', {'equipments': MechepEquip.objects.all()})


def mechep_admin_acknowledgement(request):
    return render(request, 'mechep_ack.html')
