from django.db import models
from django.core.mail import send_mail
from django.conf import settings
from datetime import date
from django.core.exceptions import ValidationError

class MechepEquip(models.Model):
    name = models.CharField(max_length=255)
    count = models.PositiveIntegerField()  # User sets this in form
    expiry_date = models.DateField(null=True, blank=True)
    expiry_alert_sent_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        is_new = self.pk is None  # Check if this is a new object before save
        super().save(*args, **kwargs)

        # If count is less than 6, send email alert
        if self.count < 6:
            send_mail(
                subject=f"Low Stock Alert: {self.name}",
                message=f"The equipment '{self.name}' has only {self.count} items left in stock.",
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[settings.ADMIN_EMAIL],
                fail_silently=False,
            )

    def clean(self):
        if self.expiry_date and self.expiry_date < date.today():
            raise ValidationError("Expiry date cannot be in the past.")

    @property
    def days_left_label(self):
        if self.expiry_date:
            days_left = (self.expiry_date - date.today()).days
            if days_left >= 0:
                return f"{days_left} day(s) left"
            else:
                return "Expired"
        return "No expiry date"
