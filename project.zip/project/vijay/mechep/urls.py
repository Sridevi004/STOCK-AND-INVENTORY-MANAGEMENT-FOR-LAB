from django.urls import path
from . import views

urlpatterns = [
    path('add/', views.mechep_add_equipment, name='mechep_add_equipment'),  # ✅ THIS IS REQUIRED
    path('view/', views.mechep_view_equipments, name='mechep_view_equipments'),
    path('damage/<int:id>/', views.mechep_damage, name='mechep_damage'),
    path('request/<int:id>/', views.mechep_request_equipment, name='mechep_request_equipment'),
    path('admin-ack/', views.mechep_admin_acknowledgement, name='mechep_admin_acknowledgement'),
]
