# lenis/urls.py
from django.urls import path
from . import views

app_name = 'lenis'

urlpatterns = [
    # Lenis system views
    path('', views.lenis_list, name='lenis_list'),                        # List all Lenis systems
    path('add/', views.add_lenis_system, name='add_leniscomputer'),      # Add or update Lenis system
    path('update/<int:id>/', views.update_lenis_system, name='update_lenis'),  # Update Lenis system

    # Move Lenis system
    path('move/<int:system_id>/', views.move_lenis_system, name='move_lenis_system'),  

    # Stack / purchase views
    path('stack/', views.stack_form, name='stack_form'),                  # Add stack
    path('stack/view/', views.stack_view, name='stack_view'),            # View all stacks

    # Complaint views
    path('complaint/<int:system_id>/', views.add_lenis_complaint, name='addlen_complaint'),   # Add complaint
    path('complaint/resolve/<int:complaint_id>/', views.resolve_lenis_complaint, name='resolvelen_complaint'),  # Resolve complaint
    path('complaints/<int:system_id>/', views.system_complaints, name='systemlen_complaints'), # List complaints for a system

    # Moved system views
    path('moved/', views.moved_lenis_list, name='lenis_moved_list'),                     # List moved systems
    path('moved/delete/<int:pk>/', views.delete_moved_lenis, name='deletelen_moved_lenis'), # Delete a moved system

    # Optional: Systems list (alias)
    path('systems/', views.lenis_list, name='systems_list'),
]
