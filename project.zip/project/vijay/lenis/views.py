# lenis/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.utils import timezone
from django.db import transaction
from .models import LenisSystem, LenisStack, LenisComplaint, MovedLenSystem, Lab
from .forms import LenisSystemForm, LenisStackForm, LenisComplaintForm, MoveSystemForm


# List all Lenis systems
def lenis_list(request):
    systems = LenisSystem.objects.all().order_by('system_number')
    return render(request, 'lenis_view.html', {'systems': systems})


# Add or update Lenis system
def add_lenis_system(request):
    systems = LenisSystem.objects.all()
    if request.method == 'POST':
        form = LenisSystemForm(request.POST)
        if form.is_valid():
            system_number = form.cleaned_data['system_number']
            software_details = form.cleaned_data['software_details']
            lab = form.cleaned_data.get('lab')
            system, created = LenisSystem.objects.get_or_create(
                system_number=system_number,
                defaults={'software_details': software_details, 'lab': lab}
            )
            if not created:
                system.software_details = software_details
                system.lab = lab
                system.save()
                messages.info(request, f"System {system_number} updated successfully.")
            else:
                messages.success(request, f"System {system_number} added successfully.")
            return redirect('lenis:lenis_list')
    else:
        form = LenisSystemForm()
    return render(request, 'lenis_form.html', {'form': form, 'systems': systems})


# Update a Lenis system
def update_lenis_system(request, id):
    system = get_object_or_404(LenisSystem, id=id)
    if request.method == 'POST':
        form = LenisSystemForm(request.POST, instance=system)
        if form.is_valid():
            form.save()
            messages.success(request, f"System {system.system_number} updated successfully.")
            return redirect('lenis:lenis_list')
    else:
        form = LenisSystemForm(instance=system)
    return render(request, 'update_lenis.html', {'form': form, 'system': system})


# Move a Lenis system to another lab
from django.shortcuts import get_object_or_404, redirect
from django.contrib import messages
from django.db import transaction
from django.apps import apps
from .models import LenisSystem, Lab, MovedLenSystem
# lenis/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.utils import timezone
from .models import LenisSystem, MovedLenSystem
from core.models import Lab
from .forms import MoveSystemForm  # your form for moving systems

def move_lenis_system(request, system_id):
    system = get_object_or_404(LenisSystem, id=system_id)

    # Exclude current lab from dropdown
    labs_qs = Lab.objects.exclude(id=system.lab.id) if system.lab else Lab.objects.all()

    if request.method == 'POST':
        form = MoveSystemForm(request.POST)
        form.fields['lab'].queryset = labs_qs

        if form.is_valid():
            target_lab = form.cleaned_data['lab']
            original_lab = system.lab

            # Update system's lab and movement info
            system.moved_from_lab = original_lab
            system.lab = target_lab
            system.is_moved = True
            system.status_note = f"Moved from {original_lab.name if original_lab else 'Unassigned'}"
            system.save()

            # Log movement
            MovedLenSystem.objects.create(
                system=system,
                moved_from_lab=original_lab,
                moved_to_lab=target_lab,
                moved_by=request.user if request.user.is_authenticated else None,
                moved_at=timezone.now(),
            )

            messages.success(
                request,
                f"System {system.system_number} moved from "
                f"{original_lab.name if original_lab else 'Unassigned'} to {target_lab.name}"
            )
            return redirect('lenis:lenis_list')

    else:
        form = MoveSystemForm()
        form.fields['lab'].queryset = labs_qs

    return render(request, "lenis_form.html", {"form": form, "system": system})

# List only moved Lenis systems
def moved_lenis_list(request):
    moved_records = MovedLenSystem.objects.select_related("system", "moved_by").order_by('-moved_at')
    return render(request, "lenis_moved.html", {"moved_records": moved_records})


# Delete a moved Lenis system
def delete_moved_lenis(request, pk):
    system = get_object_or_404(LenisSystem, pk=pk)
    if not system.is_moved:
        messages.error(request, "This system has not been moved. Cannot delete.")
        return redirect('lenis:lenis_list')
    if request.method == "POST":
        system.delete()
        messages.success(request, "Moved system deleted successfully.")
        return redirect('lenis:lenis_list')
    return render(request, "confirm_delete.html", {"system": system})


# Add complaint
def add_lenis_complaint(request, system_id):
    system = get_object_or_404(LenisSystem, id=system_id)
    if request.method == "POST":
        form = LenisComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.system = system
            complaint.save()
            messages.success(request, "Complaint added successfully!")
            return redirect("lenis:lenis_list")
    else:
        form = LenisComplaintForm()
    return render(request, "lenis_complaint_form.html", {"form": form, "system": system})


# Resolve complaint
def resolve_lenis_complaint(request, complaint_id):
    complaint = get_object_or_404(LenisComplaint, pk=complaint_id)
    system_id = complaint.system.id
    if request.method == 'POST':
        complaint.status = 'RESOLVED'
        complaint.resolved_at = timezone.now()
        complaint.save()
        messages.success(request, "Complaint resolved successfully!")
        return redirect('lenis:system_complaints', system_id=system_id)
    return render(request, 'lenis_resolve_complaint.html', {'complaint': complaint})


# List complaints of a system
def system_complaints(request, system_id):
    system = get_object_or_404(LenisSystem, pk=system_id)
    complaints = system.complaints.all().order_by('-created_at')
    return render(request, 'lencomplaint_list.html', {
        'system': system,
        'complaints': complaints
    })


# Stack views
def stack_form(request):
    if request.method == 'POST':
        form = LenisStackForm(request.POST)
        if form.is_valid():
            stack = form.save(commit=False)
            stack.created_by = request.user
            stack.save()
            messages.success(request, "Stack added successfully!")
            return redirect('lenis:stack_view')
    else:
        form = LenisStackForm()
    return render(request, 'stack_form.html', {'form': form})


def stack_view(request):
    stacks = LenisStack.objects.all().order_by('-date_of_purchase')
    return render(request, 'stack_view.html', {'stacks': stacks})
