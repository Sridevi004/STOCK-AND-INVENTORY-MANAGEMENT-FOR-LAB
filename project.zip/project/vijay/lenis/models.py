# lenis/models.py
from django.db import models
from core.models import MasterStack, Lab
from django.contrib.auth.models import User
from datetime import date

# -------------------------------
# Lenis System
# -------------------------------
class LenisSystem(models.Model):
    system_number = models.CharField(max_length=20, unique=True)
    software_details = models.TextField(blank=True)
    last_updated = models.DateTimeField(auto_now=True)

    # Current lab
    lab = models.ForeignKey(
        Lab,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='lenis_current_systems'
    )

    is_idle = models.BooleanField(default=False)
    is_moved = models.BooleanField(default=False)

    # Previous lab (nullable)
    # LenisSystem model
    moved_from_lab = models.ForeignKey('core.Lab',null=True,
    blank=True,
    on_delete=models.SET_NULL,
    related_name='lenis_moved_from_systems'
)



    status_note = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"System {self.system_number}"

# -------------------------------
# Lenis Stack
# -------------------------------
class LenisStack(models.Model):
    serial_no = models.AutoField(primary_key=True)
    year = models.PositiveIntegerField(default=date.today().year)
    bill_number = models.CharField(max_length=50, default='')
    description_of_machine = models.TextField(default='')
    date_of_purchase = models.DateField(default=date.today)
    supplier_name = models.CharField(max_length=100, default='')
    rate = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    opening_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    purchase = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def save(self, *args, **kwargs):
        self.total = self.opening_balance + self.purchase
        super().save(*args, **kwargs)

        # Sync with MasterStack
        MasterStack.objects.create(
            app_name='lenis',
            date=self.date_of_purchase,
            price=self.total,
            description=self.description_of_machine,
            created_by=self.created_by
        )

    def __str__(self):
        return f"{self.serial_no} - {self.description_of_machine} ({self.year})"

# -------------------------------
# Lenis Complaint
# -------------------------------
class LenisComplaint(models.Model):
    STATUS_CHOICES = [
        ('OPEN', 'Open'),
        ('IN_PROGRESS', 'In Progress'),
        ('RESOLVED', 'Resolved'),
    ]

    system = models.ForeignKey(LenisSystem, on_delete=models.CASCADE, related_name="complaints")
    complaint_text = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='OPEN')
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Complaint for Lenis {self.system.system_number}"

# -------------------------------
# Moved Lenis System
# -------------------------------
class MovedLenSystem(models.Model):
    system = models.ForeignKey(LenisSystem, on_delete=models.CASCADE, related_name="moved_records")
    moved_from_lab = models.ForeignKey('core.Lab', null=True, blank=True, on_delete=models.SET_NULL, related_name='moved_lenis_from')
    moved_to_lab = models.ForeignKey('core.Lab', null=True, blank=True, on_delete=models.SET_NULL, related_name='moved_lenis_to')
    moved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    moved_at = models.DateTimeField(auto_now_add=True)
