from django import forms
from .models import LenisSystem
from .models import LenisStack,LenisComplaint
from core.models import *
class LenisSystemForm(forms.ModelForm):
    class Meta:
        model = LenisSystem
        fields = ['system_number', 'software_details']

class LenisStackForm(forms.ModelForm):
    class Meta:
        model = LenisStack
        fields = [
            'year', 'bill_number', 'description_of_machine', 'date_of_purchase',
            'supplier_name', 'rate', 'opening_balance', 'purchase'
        ]
        widgets = {
            'date_of_purchase': forms.DateInput(attrs={'type': 'date'}),
            'description_of_machine': forms.Textarea(attrs={'rows': 3}),
        }

class LenisComplaintForm(forms.ModelForm):
    class Meta:
        model = LenisComplaint
        fields = ["complaint_text"]   # ✅ only take the complaint text from user
        widgets = {
            "complaint_text": forms.Textarea(attrs={
                "class": "form-control",
                "placeholder": "Describe the issue with this system...",
                "rows": 4
            }),
        }
class MoveSystemForm(forms.ModelForm):
    class Meta:
        model = LenisSystem
        fields = ['lab']
