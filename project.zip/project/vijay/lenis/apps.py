from django.apps import AppConfig


class LenisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lenis'
