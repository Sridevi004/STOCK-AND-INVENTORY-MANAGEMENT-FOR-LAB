# core/views.py
from django.shortcuts import render
from .models import MasterStack

def master_stack_list(request):
    # Get all MasterStack records
    stacks = MasterStack.objects.all()
    
    return render(request, 'master_stack_list.html', {'stacks': stacks})
