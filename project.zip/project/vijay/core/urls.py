# core/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('master-stack/', views.master_stack_list, name='master_stack_list'),
]
