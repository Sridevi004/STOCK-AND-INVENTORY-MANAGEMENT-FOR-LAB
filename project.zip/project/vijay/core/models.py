# core/models.py
from django.db import models
from django.contrib.auth.models import User
class Lab(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class MasterStack(models.Model):
    APP_CHOICES = [
        ('batchmen', 'Batchmen'),
        ('lenis', 'Lenis'),
        ('computerlab', 'Computer Lab'),
        # Add all your app names here
    ]

    app_name = models.CharField(max_length=50, choices=APP_CHOICES)
    date = models.DateField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(blank=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.app_name} - {self.date} - {self.price}"
