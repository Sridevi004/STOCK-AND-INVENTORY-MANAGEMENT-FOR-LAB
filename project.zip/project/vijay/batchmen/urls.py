from django.urls import path
from . import views



urlpatterns = [
    # Main list views
    path('', views.batchmen_list, name='batchmen_list'),
  # Consider if this duplicate is necessary
    path('list/', views.batch_view, name='list'),  # Consider consolidating with batchmen_list
    
    # System CRUD operations
    path('form/', views.batchmen_form, name='batchmen_form'),
    path('add/', views.add_or_update_batchmen, name='add_or_update_batchmen'),
    path('update/<int:id>/', views.update_batchmen, name='update_batchmen'),
    
    # System movement
    path('systems/<int:system_id>/move/', views.move_batchmen, name='move_batchmen'),
    path('move/<str:app_label>/<int:system_id>/', views.move_system_view, name='move_system'),
    path('lab/<int:lab_id>/', views.lab_view, name='lab_view'),
    path('move/<str:app_label>/<int:system_id>/', views.move_system_view, name='move_system'),
    # Stack operations
    path('stack/', views.batchmen_stack_view, name='batchmen_stack_view'),
    path('stack/add/', views.batchmen_stack_form_view, name='batchmen_stack_form'),
    
    # Complaint operations
    path('systems/<int:system_id>/complaints/', views.systembat_complaints, name='systembat_complaints'),
    path('systems/<int:system_id>/add-complaint/', views.add_complaint, name='add_complaint'),
    path('complaint/<int:complaint_id>/resolve/', views.resolvebat_complaint, name='resolvebat_complaint'),
    
    # Alias for backward compatibility (consider removing if not needed)
    path("<int:system_id>/complaint/", views.add_complaint, name="add_complaint_legacy"),
    #to view oved system
    # Show only moved systems
    path('moved/', views.moved_systems_view, name='moved_systems'),
    path('systems/<int:system_id>/delete/', views.delete_moved_system, name='delete_moved_system'),



]