from django.db import models
from core.models import *
from django.contrib.auth.models import User 
from datetime import date 
from core.models import Lab
class Lab(models.Model):
    name = models.CharField(max_length=100, unique=True)
    app_label = models.CharField(max_length=50)  # Optional: to track which app the lab belongs to

    def __str__(self):
        return self.name


class BatchmenSystem(models.Model):
    system_number = models.CharField(max_length=20)
    software_details = models.TextField(blank=True)
    lab = models.ForeignKey(Lab, null=True, blank=True, on_delete=models.SET_NULL)
    is_idle = models.BooleanField(default=False)

    # New fields for move tracking
    is_moved = models.BooleanField(default=False)  # True if this record is no longer active in current lab
    moved_from_lab = models.ForeignKey(
        Lab,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='systems_moved_from'
    )
    status_note = models.CharField(max_length=255, blank=True)

    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"System {self.system_number}"
class BatchmenStack(models.Model):
    serial_no = models.AutoField(primary_key=True)
    year = models.PositiveIntegerField(default=2025)
    bill_number = models.CharField(max_length=50, default='')  # text default
    description_of_machine = models.TextField(default='')
    date_of_purchase = models.DateField(default=date.today)     # valid date default
    supplier_name = models.CharField(max_length=100, default='') 
    rate = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    opening_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    purchase = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def save(self, *args, **kwargs):
        self.total = self.opening_balance + self.purchase
        super().save(*args, **kwargs)
        # Optional MasterStack sync
        MasterStack.objects.create(
            app_name='lenis',
            date=self.date_of_purchase,
            price=self.total,
            description=self.description_of_machine,
            created_by=self.created_by
        )

    def __str__(self):
        return f"{self.serial_no} - {self.description_of_machine} ({self.year})"
class Complaint(models.Model):
    STATUS_CHOICES = [
        ('OPEN', 'Open'),
        ('IN_PROGRESS', 'In Progress'),
        ('RESOLVED', 'Resolved'),
    ]
    system = models.ForeignKey(BatchmenSystem, on_delete=models.CASCADE, related_name="complaints")
    complaint_text = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='OPEN')
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    def __str__(self):
        return f"Complaint for {self.system.system_number}"

class MovedSystem(models.Model):
    system_id = models.PositiveIntegerField()
    app_label = models.CharField(max_length=50)
    lab = models.ForeignKey(
        Lab,
        on_delete=models.CASCADE,
        related_name="moved_systems"
    )
    moved_from_lab = models.ForeignKey(
        Lab,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="moved_systems_from_other",  # different from BatchmenSystem
    )
    moved_at = models.DateTimeField(auto_now_add=True)
    moved_by = models.ForeignKey(
        'auth.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
