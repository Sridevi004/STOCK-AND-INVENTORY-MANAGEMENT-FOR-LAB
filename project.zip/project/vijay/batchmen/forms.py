from django import forms
from .models import BatchmenSystem,BatchmenStack
from .models import Lab,Complaint
from .models import Lab
class BatchmenSystemForm(forms.ModelForm):
    class Meta:
        model = BatchmenSystem
        fields = ['system_number', 'software_details']
class MoveSystemForm(forms.ModelForm):
    lab = forms.ModelChoiceField(queryset=Lab.objects.none(), empty_label="Select Lab")

    class Meta:
        model = BatchmenSystem
        fields = ['lab']
class BatchmenStackForm(forms.ModelForm):
    class Meta:
        model = BatchmenStack
        fields = [
            'year', 'bill_number', 'description_of_machine', 'date_of_purchase',
            'supplier_name', 'rate', 'opening_balance', 'purchase'
        ]
        widgets = {
            'date_of_purchase': forms.DateInput(attrs={'type': 'date'}),
            'description_of_machine': forms.Textarea(attrs={'rows': 3}),
        }
class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ["complaint_text"]
        widgets = {
            "complaint_text": forms.Textarea(attrs={"rows":3, "placeholder":"Enter your complaint..."})
        }