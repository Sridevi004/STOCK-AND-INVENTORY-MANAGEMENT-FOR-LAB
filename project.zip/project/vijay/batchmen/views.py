from django.shortcuts import render, redirect, get_object_or_404
from .models import BatchmenSystem
from .models import *
from computerlab.models import ComputerSystem
from lenis.models import LenisSystem
from .forms import BatchmenSystemForm,MoveSystemForm
from django.db import transaction
from django.contrib import messages  # if you’re using messages in this file
from computerlab.models import Lab
from django import forms
from django.apps import apps
from django.urls import reverse
from .models import BatchmenStack,Complaint
from .forms import BatchmenStackForm,ComplaintForm
from core.models import MasterStack
from django.utils import timezone
def batchmen_list(request):
    systems = BatchmenSystem.objects.filter(is_moved=False).select_related("lab")
    moved_systems = BatchmenSystem.objects.filter(is_moved=True).select_related("lab")
    return render(request, 'batchmen_list.html', {
        'systems': systems,
        'moved_systems': moved_systems,
    })

def add_or_update_batchmen(request):
    systems = BatchmenSystem.objects.all()
    if request.method == 'POST':
        form = BatchmenSystemForm(request.POST)
        if form.is_valid():
            system_number = form.cleaned_data.get('system_number')
            software_details = form.cleaned_data.get('software_details')

            system, created = BatchmenSystem.objects.get_or_create(
                system_number=system_number,
                defaults={'software_details': software_details}
            )

            if not created:
                system.software_details = software_details
                system.save()

            return redirect('batchmen_list')  # Make sure this URL exists in urls.py
    else:
        form = BatchmenSystemForm()

    return render(request, 'batchmen_form.html', {
        'form': form,
        'systems': systems
    })

def batchmen_form(request):
    systems = BatchmenSystem.objects.all()
    if request.method == 'POST':
        form = BatchmenSystemForm(request.POST)
        if form.is_valid():
            system_number = form.cleaned_data['system_number']
            software_details = form.cleaned_data['software_details']
            system, created = BatchmenSystem.objects.get_or_create(
                system_number=system_number,
                defaults={'software_details': software_details}
            )
            if not created:
                system.software_details = software_details
                system.save()
            return redirect('batchmen_list')
    else:
        form = BatchmenSystemForm()
    return render(request, 'batchmen_form.html', {'form': form, 'systems': systems})

def update_batchmen(request, id):
    system = get_object_or_404(BatchmenSystem, id=id)
    if request.method == 'POST':
        form = BatchmenSystemForm(request.POST, instance=system)
        if form.is_valid():
            form.save()
            return redirect('batchmen_list')
    else:
        form = BatchmenSystemForm(instance=system)
    return render(request, 'update_batchmen.html', {'form': form, 'system': system})



def move_batchmen(request, system_id):
    system = get_object_or_404(BatchmenSystem, id=system_id)

    # Labs excluding current lab
    labs_qs = Lab.objects.exclude(id=system.lab.id) if system.lab else Lab.objects.all()

    if request.method == 'POST':
        form = MoveSystemForm(request.POST, instance=system)
        form.fields['lab'].queryset = labs_qs

        if form.is_valid():
            target_lab = form.cleaned_data['lab']
            original_lab = system.lab


            from_lab_name = original_lab.name if original_lab else "Unassigned"

            # Mark the original system as moved
            system.is_moved = True
            system.moved_from_lab = original_lab
            system.status_note = f"Moved from {from_lab_name}"
            system.save()

            # Create log in MovedSystem
            MovedSystem.objects.create(
                system_id=system.id,
                app_label="batchmen",
                lab=target_lab,
                moved_from_lab=original_lab,
                moved_by=request.user if request.user.is_authenticated else None
            )

            # ✅ Also create a new system instance in the target lab
            BatchmenSystem.objects.create(
                system_number=system.system_number,
                software_details=system.software_details,
                lab=target_lab,
                is_moved=False,  # It's active in the target lab now
                moved_from_lab=original_lab,
                status_note=f"Received from {from_lab_name}"
            )

            messages.success(
                request,
                f"System {system.system_number} moved from {from_lab_name} to {target_lab.name}"
            )

            return redirect('batchmen_list')

    else:
        form = MoveSystemForm(instance=system)
        form.fields['lab'].queryset = labs_qs

    return render(request, 'move_batchmen.html', {'form': form, 'system': system})

from django.shortcuts import render, get_object_or_404, redirect
from django.apps import apps
from django.contrib import messages
from batchmen.models import Lab, MovedSystem
from .forms import MoveSystemForm
from django.utils import timezone

def move_system_view(request, app_label, system_id):
    """
    Move a system from any app to any lab dynamically.
    """
    Model = apps.get_model(app_label, f"{app_label.capitalize()}System")
    system = get_object_or_404(Model, pk=system_id)

    # If system already moved, get last moved lab
    last_move = MovedSystem.objects.filter(system_id=system_id, app_label=app_label).order_by('-moved_at').first()
    current_lab = last_move.lab if last_move else None

    if request.method == "POST":
        form = MoveSystemForm(request.POST)
        if form.is_valid():
            target_lab = form.cleaned_data['lab']

            # Create moved record
            MovedSystem.objects.create(
                system_id=system.id,
                app_label=app_label,
                lab=target_lab,
                moved_from_lab=current_lab,
                moved_by=request.user
            )

            messages.success(request, f"{app_label.capitalize()} system {system_id} moved to {target_lab.name}")
            return redirect(f'/lab/{target_lab.id}/')  # Redirect to target lab view
    else:
        form = MoveSystemForm()

    return render(request, 'move_system.html', {
        'form': form,
        'system': system,
        'current_lab': current_lab,
        'app_label': app_label
    })


def lab_view(request, lab_id):
    """
    Show all systems in a lab dynamically (native + moved systems).
    """
    target_lab = get_object_or_404(Lab, pk=lab_id)

    # 1️⃣ Native systems
    try:
        NativeModel = apps.get_model(target_lab.app_label, f"{target_lab.app_label.capitalize()}System")
        native_systems = NativeModel.objects.all()
    except LookupError:
        native_systems = []

    # 2️⃣ Moved systems
    moved_records = MovedSystem.objects.filter(lab=target_lab).order_by('moved_at')
    moved_systems = []
    for rec in moved_records:
        try:
            Model = apps.get_model(rec.app_label, f"{rec.app_label.capitalize()}System")
            moved_systems.append(Model.objects.get(pk=rec.system_id))
        except:
            continue

    # Combine (optional)
    all_systems = list(native_systems) + moved_systems

    return render(request, 'lab_view.html', {
        'target_lab': target_lab,
        'native_systems': native_systems,
        'moved_systems': moved_systems,
        'all_systems': all_systems
    })


def batchmen_stack_form_view(request):
    if request.method == 'POST':
        form = BatchmenStackForm(request.POST)
        if form.is_valid():
            stack = form.save(commit=False)
            stack.created_by = request.user
            stack.save()  # saves to BatchmenStack

            # Also save into MasterStack
            MasterStack.objects.create(
                app_name='batchmen',
                date=stack.date_of_purchase,
                price=stack.total,
                description=stack.description_of_machine,
                created_by=request.user
            )

            return redirect('batchmen_stack_view')  # ✅ with namespace
    else:
        form = BatchmenStackForm()

    return render(request, 'stack_form.html', {'form': form})


# ✅ Stack List
def batchmen_stack_view(request):
    stacks = BatchmenStack.objects.all().order_by('-date_of_purchase')
    return render(request, 'stack_view.html', {'stacks': stacks})

def add_complaint(request, system_id):
    system = get_object_or_404(BatchmenSystem, id=system_id)
    if request.method == "POST":
        form = ComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.system = system
            complaint.save()
            return redirect("batchmen_list")
    else:
        form = ComplaintForm()

    return render(request, "complaint_form.html", {"form": form, "system": system})
def resolvebat_complaint(request, complaint_id):
    complaint = get_object_or_404(Complaint, pk=complaint_id)
    system_id = complaint.system.id  # Store system_id before deletion
    if request.method == 'POST':
        complaint.status = 'RESOLVED'
        complaint.resolved_at = timezone.now()
        complaint.save() 
        messages.success(request, "Complaint marked as resolved!") # Delete the complaint instead of marking as resolved
        return redirect('systembat_complaints', system_id=system_id)
    return render(request, 'resolve_complaint.html', {
        'complaint': complaint
    })
def systembat_complaints(request, system_id):
    system = get_object_or_404(BatchmenSystem, pk=system_id)
    complaints = system.complaints.all().order_by('-created_at')
    
    return render(request, 'batcomplaints_list.html', {
        'system': system,
        'complaints': complaints,
        'title': f"Complaints for BATCHMEN {system.system_number}"
    })
def batch_view(request):
    batchmen_systems = BatchmenSystem.objects.all()
    return render(request, 'batchmen_view.html', {'systems': batchmen_systems})
def moved_systems_view(request):
    moved_systems = MovedSystem.objects.select_related("lab", "moved_from_lab", "moved_by").order_by("-moved_at")
    return render(request, "moved_systems.html", {"moved_systems": moved_systems})

def delete_moved_system(request, system_id):
    system = get_object_or_404(BatchmenSystem, id=system_id)

    # Allow deletion only if the system is marked as moved
    if not system.is_moved:
        messages.error(request, "❌ Only moved systems can be deleted.")
        return redirect('batchmen_list')

    if request.method == "POST":
        lab_id = system.lab.id if system.lab else None
        system.delete()
        messages.success(request, f"🗑️ Moved system {system.system_number} deleted successfully.")
        return redirect(reverse('batchmen_list'),{"system": system})

    # Confirm page
    return render(request, "confirmbat_delete.html", {"system": system})