from django.urls import path
from . import views

app_name = 'language'

urlpatterns = [
    # List all Language systems
    path('', views.lan_list, name='lan_list'),

    # Add new Language system
    path('add/', views.add_lan_system, name='add_lan_system'),

    # Update existing system
    path('update/<int:id>/', views.update_lan_system, name='update_lan_system'),

    # Language Stack
    path('stack/add/', views.language_stack_form_view, name='language_stack_form'),
    path('stack/view/', views.language_stack_view, name='language_stack_view'),

    # Complaints
    path('complaint/add/<int:system_id>/', views.add_complaint, name='add_complaint'),
    path('complaint/list/<int:system_id>/', views.system_complaints, name='system_complaints'),
    path('complaint/resolve/<int:complaint_id>/', views.resolve_complaint, name='resolve_complaint'),

    # Move systems dynamically
    path('move/<str:source_app>/<int:system_id>/<int:target_lab_id>/', 
         views.move_lansystem, name='move_lansystem'),

    # Dynamic lab view (native + moved)
    path('lab/<int:lab_id>/', views.language_lab_view, name='language_lab_view'),

    # Moved systems list & delete
    path('moved/', views.moved_lan_list, name='moved_lan_list'),
    path('delete/<int:system_id>/', views.delete_lansystem, name='delete_lansystem'),
]
