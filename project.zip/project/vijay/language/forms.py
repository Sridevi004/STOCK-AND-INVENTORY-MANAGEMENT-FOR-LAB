# forms.py (inside your app, e.g., computerlab/forms.py)

from django import forms
from .models import LanSystem,LanguageStack,LanguageComplaint
from core.models import Lab

class LanSystemForm(forms.ModelForm):
    class Meta:
        model = LanSystem
        fields = ['system_number', 'software_details']
class LanguageStackForm(forms.ModelForm):
    class Meta:
        model = LanguageStack
        fields = [
            'year', 
            'bill_number', 
            'description_of_machine', 
            'date_of_purchase',
            'supplier_name', 
            'rate', 
            'opening_balance', 
            'purchase'
        ]
        widgets = {
            'date_of_purchase': forms.DateInput(attrs={'type': 'date'}),
            'description_of_machine': forms.Textarea(attrs={'rows': 3}),
        }
class LanguageComplaintForm(forms.ModelForm):
    class Meta:
        model = LanguageComplaint
        fields = ['complaint_text']
        widgets = {
            'complaint_text': forms.Textarea(attrs={'rows':4, 'cols':40})
        }
class MovelanSystemForm(forms.ModelForm):
    lab = forms.ModelChoiceField(
        queryset=Lab.objects.all(),
        label="Select Lab",
        empty_label="-- Choose a Lab --"
    )
    class Meta:
        model = LanSystem        # ✅ tell Django this is for LanSystem
        fields = ['lab'] 