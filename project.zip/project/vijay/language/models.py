from django.db import models
from django.contrib.auth.models import User
from datetime import date
from core.models import *
# Create your models here.
class Lab(models.Model):
    name = models.CharField(max_length=100, unique=True)
    app_label = models.CharField(max_length=50)  # Optional: to track which app the lab belongs to

    def __str__(self):
        return self.name
class LanSystem(models.Model):
    system_number = models.CharField(max_length=20, unique=True)
    software_details = models.TextField(blank=True)
    last_updated = models.DateTimeField(auto_now=True)
    lab = models.ForeignKey('core.Lab', on_delete=models.SET_NULL, null=True, blank=True)  # 👈 add this
    is_idle = models.BooleanField(default=False)
    is_moved = models.BooleanField(default=False)
    moved_from_lab = models.CharField(max_length=100, blank=True, null=True)
    status_note = models.TextField(blank=True, null=True)
    
    
    
    def __str__(self):
        return f"System {self.system_number}"

class LanguageStack(models.Model):
    serial_no = models.AutoField(primary_key=True)
    year = models.PositiveIntegerField(default=2025)
    bill_number = models.CharField(max_length=50, default='')
    description_of_machine = models.TextField(default='')
    date_of_purchase = models.DateField(default=date.today)
    supplier_name = models.CharField(max_length=100, default='') 
    rate = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    opening_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    purchase = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def save(self, *args, **kwargs):
        # Auto calculate total
        self.total = self.opening_balance + self.purchase
        super().save(*args, **kwargs)

        # Sync to MasterStack (optional, if needed)
        MasterStack.objects.create(
            app_name='language',
            date=self.date_of_purchase,
            price=self.total,
            description=self.description_of_machine,
            created_by=self.created_by
        )

    def __str__(self):
        return f"{self.serial_no} - {self.description_of_machine} ({self.year})"
class LanguageComplaint(models.Model):
    STATUS_CHOICES = [
        ('OPEN', 'Open'),
        ('IN_PROGRESS', 'In Progress'),
        ('RESOLVED', 'Resolved'),
    ]
    system = models.ForeignKey(LanSystem, on_delete=models.CASCADE, related_name="complaints")
    complaint_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='OPEN')
    resolved_at = models.DateTimeField(null=True, blank=True)
    def __str__(self):
        return f"Complaint for {self.system.system_number}"
class MovedLan(models.Model):
    system = models.ForeignKey(LanSystem, on_delete=models.CASCADE, related_name="moved_records")
    moved_from_lab = models.CharField(max_length=100, blank=True, null=True)
    moved_to_lab = models.CharField(max_length=100, blank=True, null=True)
    moved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    moved_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.system} moved at {self.moved_at}"