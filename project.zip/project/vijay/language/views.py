from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.apps import apps
from django.db import transaction
from .models import LanSystem, LanguageStack, LanguageComplaint, MovedLan, Lab
from .forms import LanSystemForm, LanguageStackForm, LanguageComplaintForm, MovelanSystemForm
from core.models import MasterStack

# ----------------------
# LIST & VIEW SYSTEMS
# ----------------------
def lan_list(request):
    """List all Language systems."""
    systems = LanSystem.objects.all().order_by('system_number')
    return render(request, 'lan_list.html', {'lansystems': systems})


def lan_view(request):
    """Show all systems and the lab info."""
    try:
        language_lab = Lab.objects.get(name__icontains="Language Lab")
    except Lab.DoesNotExist:
        language_lab = None

    lansystems = LanSystem.objects.all()
    return render(request, 'lan_list.html', {
        'lansystems': lansystems,
        'lab': language_lab
    })


def add_lan_system(request):
    """Add a new Language system."""
    systems = LanSystem.objects.all()

    if request.method == 'POST':
        form = LanSystemForm(request.POST)
        if form.is_valid():
            system_number = form.cleaned_data['system_number']
            software_details = form.cleaned_data['software_details']

            system, created = LanSystem.objects.get_or_create(
                system_number=system_number,
                defaults={'software_details': software_details}
            )

            if not created:
                system.software_details = software_details
                system.save()

            return redirect('language:lan_list')
    else:
        form = LanSystemForm()

    return render(request, 'lan_form.html', {'form': form, 'lansystems': systems})


def update_lan_system(request, id):
    """Update an existing Language system."""
    system = get_object_or_404(LanSystem, id=id)

    if request.method == 'POST':
        form = LanSystemForm(request.POST, instance=system)
        if form.is_valid():
            form.save()
            messages.success(request, f"System {system.system_number} updated successfully.")
            return redirect('language:lan_list')
    else:
        form = LanSystemForm(instance=system)

    return render(request, 'update_lan.html', {'form': form, 'system': system})


# ----------------------
# LANGUAGE STACK
# ----------------------
def language_stack_form_view(request):
    """Add a new stack for Language Lab."""
    if request.method == 'POST':
        form = LanguageStackForm(request.POST)
        if form.is_valid():
            stack = form.save(commit=False)
            stack.created_by = request.user
            stack.save()

            # Save to MasterStack
            MasterStack.objects.create(
                app_name='language',
                date=stack.date_of_purchase,
                price=stack.total,
                description=stack.description_of_machine,
                created_by=request.user
            )

            return redirect('language:language_stack_view')
    else:
        form = LanguageStackForm()

    return render(request, 'stack_form.html', {'form': form})


def language_stack_view(request):
    """View all stacks."""
    stacks = LanguageStack.objects.all().order_by('-date_of_purchase')
    return render(request, 'language/stack_view.html', {'stacks': stacks})


# ----------------------
# COMPLAINTS
# ----------------------
def add_complaint(request, system_id):
    """Add complaint for a Language system."""
    system = get_object_or_404(LanSystem, id=system_id)

    if request.method == 'POST':
        form = LanguageComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.system = system
            complaint.save()
            return redirect('language:lan_list')
    else:
        form = LanguageComplaintForm()

    return render(request, 'add_complaint.html', {'form': form, 'system': system})


def system_complaints(request, system_id):
    """List complaints for a specific system."""
    system = get_object_or_404(LanSystem, id=system_id)
    complaints = system.complaints.all().order_by('-created_at')
    return render(request, 'complaints_list.html', {'system': system, 'complaints': complaints})


def resolve_complaint(request, complaint_id):
    """Resolve a specific complaint."""
    complaint = get_object_or_404(LanguageComplaint, id=complaint_id)

    if request.method == 'POST':
        complaint.status = 'RESOLVED'
        complaint.resolved_at = timezone.now()
        complaint.save()
        messages.success(request, f"Complaint for system {complaint.system.system_number} marked as resolved.")
        return redirect('language:system_complaints', system_id=complaint.system.id)

    return render(request, 'resolve_complaint.html', {'complaint': complaint})


# ----------------------
# DYNAMIC LAB VIEW
# ----------------------
def language_lab_view(request, lab_id):
    """Dynamic view of a lab: native + moved systems."""
    lab = get_object_or_404(Lab, id=lab_id)

    # Native Language systems
    native_systems = LanSystem.objects.filter(lab=lab, is_moved=False)

    # Moved systems
    moved_records = MovedLan.objects.filter(lab=lab)
    moved_systems = []
    for rec in moved_records:
        try:
            moved_systems.append(LanSystem.objects.get(pk=rec.system.id))
        except LanSystem.DoesNotExist:
            continue

    all_systems = list(native_systems) + moved_systems

    return render(request, 'language_lab_view.html', {
        'lab': lab,
        'native_systems': native_systems,
        'moved_systems': moved_systems,
        'all_systems': all_systems
    })


# ----------------------
# MOVE SYSTEMS DYNAMICALLY
# ----------------------
LAB_MODEL_MAP = {
    "batchmen": ("BatchmenSystem", "BatchmenLab"),
    "lenis": ("LenisSystem", "LenisLab"),
    "language": ("LanSystem", "LanguageLab"),
    "computerlab": ("ComputerSystem", "ComputerLab"),
}


def move_lansystem(request, source_app, system_id, target_lab_id):
    """Move a system from any app to a target Language lab."""
    source_model_name, _ = LAB_MODEL_MAP.get(source_app.lower())
    SourceModel = apps.get_model(source_app, source_model_name)
    system = get_object_or_404(SourceModel, id=system_id)
    target_lab = get_object_or_404(Lab, id=target_lab_id)

    original_lab = getattr(system, 'lab', None)
    from_lab_name = original_lab.name if original_lab else "Unassigned"

    with transaction.atomic():
        # Mark source system as moved
        system.is_moved = True
        system.status_note = f"Moved to {target_lab.name}"
        system.save()

        # Create / get system in target lab
        lan_system, created = LanSystem.objects.get_or_create(
            system_number=system.system_number,
            defaults={
                'software_details': getattr(system, 'software_details', ''),
                'lab': target_lab,
                'is_moved': False,
                'status_note': f"Received from {from_lab_name}"
            }
        )

        # Log movement
        MovedLan.objects.create(
            system=lan_system,
            moved_from_lab=from_lab_name,
            moved_to_lab=target_lab.name,
            moved_by=request.user if request.user.is_authenticated else None
        )

    messages.success(request, f"System {system.system_number} moved from {from_lab_name} to {target_lab.name}")
    return redirect('language:language_lab_view', lab_id=target_lab.id)


# ----------------------
# VIEW & DELETE MOVED SYSTEMS
# ----------------------
def moved_lan_list(request):
    """View only moved systems in the Language Lab."""
    moved_records = MovedLan.objects.select_related('system', 'moved_by').order_by('-moved_at')
    return render(request, 'lan_movedsystem.html', {'moved_records': moved_records})


def delete_lansystem(request, system_id):
    """Delete a moved Language system."""
    system = get_object_or_404(LanSystem, id=system_id, is_moved=True)
    system.delete()
    messages.success(request, f"Moved system {system.system_number} deleted successfully.")
    return redirect('language:lan_list')
