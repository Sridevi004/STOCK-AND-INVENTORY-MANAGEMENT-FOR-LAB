from django.urls import path
from . import views

urlpatterns = [
    # List all systems
    path('computerlab/', views.computer_list, name='computer_list'),
    path('computerview',views.computer_view,name='computer_view'),
    # Add or update a system
    path('', views.add_or_update_computer, name='add_or_update_computer'),

    # Update a specific system
    path('system/update/<int:id>/', views.update_system, name='update_system'),

    # Move a system to another lab
    path('systems/<int:system_id>/move/', views.move_system_view, name='move_system'),

    # Stack management
    path('stack/add/', views.computerlab_stack_form, name='computerlab_stack_form'),
    path('stack/view/', views.computerlab_stack_view, name='computerlab_stack_view'),

    # Complaints
    path('<int:system_id>/complaint/', views.add_computer_complaint, name='add_complaint'),
    path('systems/<int:system_id>/complaints/', views.system_complaints, name='system_complaints'),
    path('complaints/<int:complaint_id>/resolve/', views.resolve_complaint, name='resolve_complaint'),

    # Movement history
    path('history/', views.movement_history, name='movement_history'),

    # Delete a moved system
    path('systems/delete/<int:system_id>/', views.delete_moved_system, name='delete_moved_system'),

    # Dynamic lab view (show all systems in a lab)
    path('lab/<int:lab_id>/', views.dynamic_lab_view, name='lab_view'),
]
