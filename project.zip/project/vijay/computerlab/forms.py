# forms.py (inside your app, e.g., computerlab/forms.py)

from django import forms
from .models import ComputerSystem,ComputerlabStack,ComputerComplaint
from .models import Lab
class ComputerSystemForm(forms.ModelForm):
    class Meta:
        model = ComputerSystem
        fields = ['system_number', 'software_details']

class MoveSystemForm(forms.Form):
    lab = forms.ModelChoiceField(
        queryset=Lab.objects.all(),
        label="Select Lab",
        empty_label="-- Choose a Lab --"
    )
class ComputerlabStackForm(forms.ModelForm):
    class Meta:
        model = ComputerlabStack
        fields = [
            'year', 'bill_number', 'description_of_machine', 'date_of_purchase',
            'supplier_name', 'rate', 'opening_balance', 'purchase'
        ]
        widgets = {
            'date_of_purchase': forms.DateInput(attrs={'type': 'date'}),
            'description_of_machine': forms.Textarea(attrs={'rows': 3}),
        }
class ComputerComplaintForm(forms.ModelForm):
    class Meta:
        model = ComputerComplaint
        fields = ['complaint_text']
        widgets = {
            'complaint_text': forms.Textarea(attrs={'rows': 4, 'cols': 40, 'placeholder': 'Describe your complaint...'}),
        }
        labels = {
            'complaint_text': 'Complaint',
        }