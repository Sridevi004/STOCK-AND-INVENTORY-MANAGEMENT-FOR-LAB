from django.db import models
from core.models import MasterStack
from django.contrib.auth.models import User
from datetime import date 
from django.utils import timezone

class Lab(models.Model):
    name = models.CharField(max_length=100, unique=True)
    app_label = models.CharField(max_length=50)  # Optional: to track which app the lab belongs to

    def __str__(self):
        return self.name


class ComputerSystem(models.Model):
    system_number = models.CharField(max_length=20)
    software_details = models.TextField(blank=True)
    lab = models.ForeignKey(
        Lab, null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="systems"
    )
    is_idle = models.BooleanField(default=False)

    # Move tracking
    is_moved = models.BooleanField(default=False)  
    moved_from_lab = models.ForeignKey(
        Lab,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='systems_moved_from'
    )
    status_note = models.CharField(max_length=255, blank=True)

    last_updated = models.DateTimeField(auto_now=True)

    # ✅ NEW field to "lock in" the original name
    system_name = models.CharField(max_length=255, blank=True, null=True)

    def save(self, *args, **kwargs):
        # If system_name is not set, create it once from lab + number
        if  self.lab:
            self.system_name = f"{self.lab.name} System {self.system_number}"
        super().save(*args, **kwargs)

    def __str__(self):
        return self.system_name or f"System {self.system_number}"

class ComputerlabStack(models.Model):
    serial_no = models.AutoField(primary_key=True)
    year = models.PositiveIntegerField(default=2025)
    bill_number = models.CharField(max_length=50, default='')  # text default
    description_of_machine = models.TextField(default='')
    date_of_purchase = models.DateField(default=date.today)     # valid date default
    supplier_name = models.CharField(max_length=100, default='') 
    rate = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    opening_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    purchase = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def save(self, *args, **kwargs):
        self.total = self.opening_balance + self.purchase
        super().save(*args, **kwargs)
        # Optional MasterStack sync
        MasterStack.objects.create(
            app_name='lenis',
            date=self.date_of_purchase,
            price=self.total,
            description=self.description_of_machine,
            created_by=self.created_by
        )

    def __str__(self):
        return f"{self.serial_no} - {self.description_of_machine} ({self.year})"
class ComputerComplaint(models.Model):
    STATUS_CHOICES = [
        ('OPEN', 'Open'),
        ('IN_PROGRESS', 'In Progress'),
        ('RESOLVED', 'Resolved'),
    ]
    system = models.ForeignKey(
        ComputerSystem, 
        on_delete=models.CASCADE, 
        related_name="complaints"
    )
    complaint_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='OPEN')
    resolved_at = models.DateTimeField(null=True, blank=True)
    def __str__(self):
        return f"Complaint for Computer {self.system.system_number}"
# ----------------------
# Movement History Model
# ----------------------
class SystemMovement(models.Model):
    system = models.ForeignKey(
        'ComputerSystem', 
        on_delete=models.CASCADE, 
        related_name='movements'
    )
    from_lab = models.ForeignKey(
        Lab, 
        null=True, blank=True, 
        on_delete=models.SET_NULL, 
        related_name='movements_from'
    )
    to_lab = models.ForeignKey(
        Lab, 
        null=True, blank=True, 
        on_delete=models.SET_NULL, 
        related_name='movements_to'
    )
    moved_at = models.DateTimeField(auto_now_add=True)
    moved_by = models.ForeignKey(
        User, null=True, blank=True, 
        on_delete=models.SET_NULL
    )

    def __str__(self):
        from_name = self.from_lab.name if self.from_lab else "Unassigned"
        to_name = self.to_lab.name if self.to_lab else "Unassigned"
        return f"{self.system} moved from {from_name} to {to_name} at {self.moved_at}"
