from django.shortcuts import render, redirect, get_object_or_404
from django.apps import apps
from django.db import transaction
from django.contrib import messages
from django.urls import reverse
from django.utils import timezone

from .models import ComputerSystem, ComputerComplaint, ComputerlabStack, SystemMovement
from .forms import ComputerSystemForm, MoveSystemForm, ComputerComplaintForm, ComputerlabStackForm
from core.models import Lab, MasterStack

def computer_view(request):
    systems = ComputerSystem.objects.all()
    form = ComputerSystemForm()
    return render(request, 'computer_view.html', {'form': form,'systems':systems})
# ----------------------
# Computer Lab: List & Add/Update Systems
# ----------------------
def computer_list(request):
    systems = ComputerSystem.objects.filter(is_moved=False).select_related("lab")
    moved_systems = ComputerSystem.objects.filter(is_moved=True).select_related("lab")
    return render(request, 'computer_list.html', {
        'systems': systems,
        'moved_systems': moved_systems,
    })


def add_or_update_computer(request):
    systems = ComputerSystem.objects.all()
    if request.method == 'POST':
        form = ComputerSystemForm(request.POST)
        if form.is_valid():
            system_number = form.cleaned_data['system_number']
            software_details = form.cleaned_data['software_details']

            system, created = ComputerSystem.objects.get_or_create(
                system_number=system_number,
                defaults={'software_details': software_details}
            )

            if not created:
                system.software_details = software_details
                system.save()

            return redirect('computer_view')
    else:
        form = ComputerSystemForm()

    return render(request, 'computer_form.html', {'form': form, 'systems': systems})


def update_system(request, id):
    system = get_object_or_404(ComputerSystem, id=id)
    if request.method == 'POST':
        form = ComputerSystemForm(request.POST, instance=system)
        if form.is_valid():
            form.save()
            return redirect('computer_list')
    else:
        form = ComputerSystemForm(instance=system)
    return render(request, 'update_system.html', {'form': form, 'system': system})


# ----------------------
# Dynamic Lab View
# ----------------------
def dynamic_lab_view(request, lab_id):
    """
    Show all systems in a lab (native + moved-in systems from other apps)
    """
    target_lab = get_object_or_404(Lab, id=lab_id)

    # 1️⃣ Native systems assigned to this lab
    try:
        Model = apps.get_model(target_lab.app_label, f"{target_lab.app_label.capitalize()}System")
        native_systems = Model.objects.filter(lab=target_lab, is_moved=False)
    except LookupError:
        native_systems = []

    # 2️⃣ Moved-in systems from all apps
    moved_systems = []
    for app in ['computerlab', 'batchmen', 'lenis', 'language']:
        try:
            Model = apps.get_model(app, f"{app.capitalize()}System")
            moved_systems += list(Model.objects.filter(is_moved=True, lab=target_lab))
        except LookupError:
            continue

    all_systems = list(native_systems) + moved_systems

    return render(request, 'comlab_view.html', {
        'target_lab': target_lab,
        'native_systems': native_systems,
        'moved_systems': moved_systems,
        'all_systems': all_systems,
    })


# ----------------------
# Dynamic Move System
# ----------------------
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages
from django.utils import timezone
from .models import Lab, SystemMovement  # adjust imports
from .forms import MoveSystemForm
from .models import ComputerSystem  # or BatchmenSystem, etc.

def move_system_view(request, system_id):
    system = get_object_or_404(ComputerSystem, id=system_id)

    # Exclude current lab from dropdown
    labs_qs = Lab.objects.exclude(id=system.lab.id) if system.lab else Lab.objects.all()

    if request.method == 'POST':
        form = MoveSystemForm(request.POST)
        form.fields['lab'].queryset = labs_qs

        if form.is_valid():
            target_lab = form.cleaned_data['lab']
            original_lab = system.lab

            # Update system's lab and movement info
            system.moved_from_lab = original_lab
            system.lab = target_lab
            system.is_moved = True
            system.status_note = f"Moved from {original_lab.name if original_lab else 'Unassigned'}"
            system.save()

            # Log movement
            SystemMovement.objects.create(
                system=system,
                from_lab=original_lab,
                to_lab=target_lab,
                moved_by=request.user if request.user.is_authenticated else None,
                moved_at=timezone.now(),
            )

            messages.success(
                request,
                f"System {system.system_number} moved from "
                f"{original_lab.name if original_lab else 'Unassigned'} to {target_lab.name}"
            )
            return redirect('computer_view')  # adjust redirect as needed

    else:
        form = MoveSystemForm()
        form.fields['lab'].queryset = labs_qs

    return render(request, "move_system.html", {"form": form, "system": system})

# ----------------------
# Movement History
# ----------------------


from computerlab.models import SystemMovement

def movement_history(request):
    moved_systems = SystemMovement.objects.select_related('system', 'from_lab', 'to_lab', 'moved_by').order_by('-moved_at')
    return render(request, 'movement_history.html', {'moved_systems': moved_systems})




# ----------------------
# Delete Moved System
# ----------------------
def delete_moved_system(request, system_id):
    system = get_object_or_404(ComputerSystem, id=system_id)
    if not system.is_moved:
        messages.error(request, "Only moved systems can be deleted.")
        return redirect('computer_list')

    if request.method == 'POST':
        system.delete()
        messages.success(request, f"Moved system {system.system_number} deleted successfully.")
        return redirect('computer_list')

    return render(request, 'confirm_delete.html', {'system': system})


# ----------------------
# Computer Stack
# ----------------------
def computerlab_stack_form(request):
    if request.method == 'POST':
        form = ComputerlabStackForm(request.POST)
        if form.is_valid():
            stack = form.save(commit=False)
            stack.created_by = request.user
            stack.save()

            # Save to MasterStack
            MasterStack.objects.create(
                app_name='computerlab',
                date=stack.date_of_purchase,
                price=stack.total,
                description=stack.description_of_machine,
                created_by=request.user
            )

            return redirect('computerlab_stack_view')
    else:
        form = ComputerlabStackForm()

    return render(request, 'stackden_form.html', {'form': form, 'lab_name': 'Computer Lab'})


def computerlab_stack_view(request):
    stacks = ComputerlabStack.objects.all().order_by('-date_of_purchase')
    return render(request, 'stackden_view.html', {'stacks': stacks, 'lab_name': 'Computer Lab'})


# ----------------------
# Complaints
# ----------------------
def add_computer_complaint(request, system_id):
    system = get_object_or_404(ComputerSystem, id=system_id)
    if request.method == 'POST':
        form = ComputerComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.system = system
            complaint.save()
            return redirect('computer_list')
    else:
        form = ComputerComplaintForm()
    return render(request, 'complaint_form.html', {'form': form, 'system': system})


def system_complaints(request, system_id):
    system = get_object_or_404(ComputerSystem, pk=system_id)
    complaints = system.complaints.all().order_by('-created_at')
    return render(request, 'complaints_list.html', {'system': system, 'complaints': complaints})


def resolve_complaint(request, complaint_id):
    complaint = get_object_or_404(ComputerComplaint, pk=complaint_id)
    if request.method == 'POST':
        complaint.status = 'RESOLVED'
        complaint.resolved_at = timezone.now()
        complaint.save()
        messages.success(request, "Complaint marked as resolved!")
        return redirect('system_complaints', system_id=complaint.system.id)

    return render(request, 'resolve_complaint.html', {'complaint': complaint})
