from django.shortcuts import render, redirect,get_object_or_404
from .forms import ChemistryProductForm
from .models import *
from .forms import *
from decimal import Decimal
from .forms import ChemistryStackForm
from .models import ChemistryStack
from core.models import MasterStack 
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone


def chemistry(request):
    products = ChemistryProduct.objects.all()
    equipments = ChemistryEquip.objects.all()
    return render(request,'bosscview.html', {'products': products,'equipments': equipments})
def add_chemistry_product(request):
    if request.method == 'POST':
        form = ChemistryProductForm(request.POST)
        print("Chemistry form submitted")

        if form.is_valid():
            print("Form is valid")
            product_name = form.cleaned_data.get('name')
            quantity_of_bottles = form.cleaned_data.get('quantity_of_bottles')
            quantity = form.cleaned_data.get('quantity')
            unit = form.cleaned_data.get('unit')

            print(f"Product: {product_name}, Bottles: {quantity_of_bottles}, Quantity: {quantity}, Unit: {unit}")

            if quantity_of_bottles is None:
                form.add_error('quantity_of_bottles', 'Quantity of bottles cannot be empty.')
                return render(request, 'add_product.html', {'form': form})

            product, created = ChemistryProduct.objects.get_or_create(
                name=product_name,  # ✅ fixed here
                unit=unit,
                defaults={
                    'quantity_of_bottles': quantity_of_bottles,
                    'quantity': quantity
                }
            )

            if not created:
                product.quantity_of_bottles += quantity_of_bottles
                product.quantity += quantity
            else:
                product.quantity_of_bottles = quantity_of_bottles
                product.quantity = quantity

            product.save()
            print("Chemistry product saved successfully")
            return redirect('list_chemistry_products')
        else:
            print("Form not valid:", form.errors)
    else:
        form = ChemistryProductForm()

    return render(request, 'addchemical.html', {'form': form})

def list_chemistry_products(request):
    products = ChemistryProduct.objects.all()
    return render(request, 'chemistry_ass.html', {'products': products})

def mark_daily_usage(request, id):
    product = get_object_or_404(ChemistryProduct, id=id)

    if request.method == 'POST':
        form = DailyUsageForm(request.POST)
        if form.is_valid():
            # Ensure Decimal for used_quantity
            used_quantity = Decimal(str(form.cleaned_data['used_quantity']))
            used_unit = form.cleaned_data['unit']

            # Conversion to base unit (ml or mg)
            unit_multipliers = {
                'L': Decimal('1000'),
                'ML': Decimal('1'),
                'G': Decimal('1000'),
                'MG': Decimal('1')
            }

            used_base = used_quantity * unit_multipliers[used_unit]       # usage in ml or mg
            available_base = product.get_total_base_unit()                # stock in ml or mg (should return Decimal)

            if used_base > available_base:
                form.add_error('used_quantity', 'Usage exceeds available stock.')
            else:
                # ✅ Update inventory (simple reduction logic)
                remaining_base = available_base - used_base

                # Convert back to quantity per bottle for update
                per_bottle_base = product.quantity * unit_multipliers[product.unit]

                if per_bottle_base > 0:
                    new_bottle_count = int(remaining_base // per_bottle_base)
                    new_quantity = (remaining_base % per_bottle_base) / unit_multipliers[product.unit]
                else:
                    new_bottle_count = 0
                    new_quantity = Decimal('0')

                product.quantity_of_bottles = new_bottle_count
                product.quantity = new_quantity
                product.save()

                # ✅ Alert if stock is below minimum threshold
                if remaining_base < product.minimum_quantity:
                    send_mail(
                        subject='[Alert] Chemistry Product Stock Low',
                        message=f'Stock for "{product.name}" is below the minimum threshold!\nRemaining: {remaining_base:.2f} (in ml/mg).',
                        from_email=settings.DEFAULT_FROM_EMAIL,
                        recipient_list=['admin@example.com'],
                        fail_silently=False,
                    )

                return redirect('list_chemistry_products')
    else:
        form = DailyUsageForm()

    return render(request, 'mark_daily_usage.html', {'form': form, 'product': product})

def chemistry_stack_form(request):
    if request.method == 'POST':
        form = ChemistryStackForm(request.POST)
        if form.is_valid():
            stack = form.save(commit=False)
            stack.created_by = request.user
            stack.save()  # saves to ChemistryStack

            # Save also to MasterStack
            MasterStack.objects.create(
                app_name='chemistry',
                date=stack.date_of_purchase,
                price=stack.total,
                description=stack.description_of_machine,
                created_by=request.user
            )

            return redirect('chemistry_stack_view')  # redirect to chemistry stack list
    else:
        form = ChemistryStackForm()

    return render(request, 'chemistry_stack_form.html', {'form': form})


# Chemistry Stack List View
def chemistry_stack_view(request):
    stacks = ChemistryStack.objects.all().order_by('-date_of_purchase')
    return render(request, 'chemistry_stack_view.html', {'stacks': stacks})
def chemical_view(request):
    products = ChemistryProduct.objects.all()
    return render(request, "chemistry_ass.html",{'products':products})


def add_chemistry_equipment(request):
    if request.method == 'POST':
        form = ChemistryEquipForm(request.POST)
        print("Form submitted")

        if form.is_valid():
            print("Form is valid")
            name = form.cleaned_data.get('name')
            count = form.cleaned_data.get('count')
            expiry_date = form.cleaned_data.get('expiry_date', None)

            print(f"Name: {name}, Count: {count}, Expiry Date: {expiry_date}")

            # Ensure count is not missing
            if count is None:
                form.add_error('count', 'Count cannot be empty.')
                return render(request, 'chemistry/add_chemistry_equip.html', {'form': form})

            # Check if equipment already exists
            equipment, created = ChemistryEquip.objects.get_or_create(
                name=name,
                defaults={
                    'count': count,
                    
                }
            )

            if not created:
                equipment.count += count
               
            else:
                equipment.count = count
                

            equipment.save()
            print("Saved successfully")
            return redirect('material_view')
        else:
            print("Form not valid:", form.errors)
    else:
        form = ChemistryEquipForm()

    return render(request, 'add_chemistry_equip.html', {'form': form})
def material_view(request):
    equipments = ChemistryEquip.objects.all()
    return render(request, 'materials.html', {'equipments': equipments})
def buttonboth(request):
    return render(request,'add_product.html')



def chemistry_damage(request, id):
    equipment = get_object_or_404(ChemistryEquip, id=id)
    if request.method == 'POST':
        if equipment.count > 0:   # avoid negative values
            equipment.count -= 1
            equipment.save()
        return redirect('material_view')   # redirect to chemistry list page

    equipments = ChemistryEquip.objects.all()
    return render(request, 'materials.html', {'equipments': equipments})



# ✅ Request Equipment (with email + saving to ChemistryRequest model)
def request_equipment_email(request, id):
    equipment = get_object_or_404(ChemistryEquip, id=id)

    if request.method == "POST":
        user_info = ""
        custom_user = None

        if request.user.is_authenticated:
            user_info = f"\n\nRequested by: {request.user.username} ({request.user.email})"
            custom_user = request.user  # ✅ directly use request.user

        try:
            # ✅ Send email
            send_mail(
                subject=f"Request for Equipment: {equipment.name}",
                message=(
                    f"The user has requested the equipment:\n\n"
                    f"Name: {equipment.name}\nCount Available: {equipment.count}{user_info}"
                ),
                from_email=settings.EMAIL_HOST_USER,
                recipient_list=['amirasri1835@gmail.com'],  # change recipient as needed
                fail_silently=False,
            )

            # ✅ Save request in DB (only if user logged in)
            if custom_user:
                ChemistryRequest.objects.create(
                    user=custom_user,
                    message=f"Requested equipment: {equipment.name}"
                )

            messages.success(request, f"Request for {equipment.name} has been sent successfully.")
        except Exception as e:
            messages.error(request, f"Failed to send request: {e}")

        return redirect('material_view')   # back to combined page

    return redirect('material_view')


# Add damage report
def add_chemistry_damage_report(request):
    if request.method == "POST":
        form = ChemistryDamageReportForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "✅ Damage report added successfully.")
            return redirect('chemistry_damage_report_list')
    else:
        form = ChemistryDamageReportForm()
    return render(request, 'addche_damage_report.html', {'form': form})

# List all reports
def chemistry_damage_report_list(request):
    reports = ChemistryDamageReport.objects.all().order_by('-date_reported')
    return render(request, 'damageche_report_list.html', {'reports': reports})

# Mark as paid
def mark_chemistry_damage_paid(request, id):
    report = get_object_or_404(ChemistryDamageReport, id=id)
    report.paid = True
    report.paid_date = timezone.now()
    report.save()
    messages.success(request, "✅ Payment marked successfully.")
    return redirect('chemistry_damage_report_list')
def chetoggle_paid(request, pk):
    report = get_object_or_404(ChemistryDamageReport, pk=pk)
    report.paid = not report.paid
    if report.paid:
        report.paid_date = timezone.now()  # Set current timestamp when marked paid
    else:
        report.paid_date = None  
    report.save()
    return redirect("chemistry_damage_report_list")