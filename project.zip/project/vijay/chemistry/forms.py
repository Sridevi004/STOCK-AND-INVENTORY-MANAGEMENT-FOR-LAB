from django import forms
from chemistry.models import *
from .models import ChemistryStack

class ChemistryProductForm(forms.ModelForm):
    class Meta:
        model = ChemistryProduct
        fields = ['name', 'quantity_of_bottles', 'quantity', 'unit']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'quantity_of_bottles': forms.NumberInput(attrs={'class': 'form-control'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control'}),
            'unit': forms.Select(attrs={'class': 'form-control'}),
        }

class DailyUsageForm(forms.Form):
    used_quantity = forms.FloatField(
        min_value=0.01,
        label="Quantity Used Today",
        widget=forms.NumberInput(attrs={'class': 'form-control'})
    )

    unit = forms.ChoiceField(  # Add this field
        choices=[
            ('L', 'Litre'),
            ('ML', 'Millilitre'),
            ('G', 'Gram'),
            ('MG', 'Milligram'),
        ],
        widget=forms.Select(attrs={'class': 'form-control'})
    )
class ChemistryStackForm(forms.ModelForm):
    class Meta:
        model = ChemistryStack
        fields = [
            'year', 'bill_number', 'description_of_machine', 'date_of_purchase',
            'supplier_name', 'rate', 'opening_balance', 'purchase', 'total'
        ]
        widgets = {
            'date_of_purchase': forms.DateInput(attrs={'type': 'date'}),
            'description_of_machine': forms.Textarea(attrs={'rows': 3}),
        }
class ChemistryEquipForm(forms.ModelForm):
    class Meta:
        model = ChemistryEquip
        fields = ['name', 'count']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'count': forms.NumberInput(attrs={'class': 'form-control'}),
        }
class ChemistryDamageReportForm(forms.ModelForm):
    class Meta:
        model = ChemistryDamageReport
        fields = ['equipment', 'student_name', 'register_no', 'department', 'year', 'amount']
