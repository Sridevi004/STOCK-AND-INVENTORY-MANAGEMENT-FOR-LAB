# chemistry/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('chemistry/', views.chemistry, name='chemistry/'),
    path('add_chemistry_product', views.add_chemistry_product, name='add_chemistry_product'),
    path('chemistry/list/', views.list_chemistry_products, name='list_chemistry_products'),
    path('daily_usage/<int:id>/', views.mark_daily_usage, name='mark_daily_usage'),
    path('stack/form/', views.chemistry_stack_form, name='chemistry_stack_form'),
    path('stack/view/', views.chemistry_stack_view, name='chemistry_stack_view'),
    path('chemical_view', views.chemical_view, name='chemical_view'),
    path('chemistry/equipment/add/', views.add_chemistry_equipment, name='add_chemistry_equipment'),
    # 👇 add this
    path('material_view', views.material_view, name='material_view'),
    path('addequip',views.buttonboth,name='buttonboth'),
 
    path('chemical/damage/<int:id>/', views.chemistry_damage, name='chemistry_damage'),
    path('chemical/request/<int:id>/', views.request_equipment_email, name='request_equipment_email'),
    path('chemistry/add-damage/', views.add_chemistry_damage_report, name='add_chemistry_damage_report'),
    path('chemistry/damage-reports/', views.chemistry_damage_report_list, name='chemistry_damage_report_list'),
    path('chemistry/damage/paid/<int:id>/', views.mark_chemistry_damage_paid, name='mark_chemistry_damage_paid'),
    path("damage-report/<int:pk>/chetoggle-paid/", views.chetoggle_paid, name="chetoggle_paid"),




]
