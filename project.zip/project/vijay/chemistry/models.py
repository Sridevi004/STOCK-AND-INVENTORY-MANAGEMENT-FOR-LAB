from django.db import models
from core.models import MasterStack
from django.contrib.auth.models import User 
from datetime import date  
from django.contrib.auth import get_user_model

User = get_user_model()
class ChemistryProduct(models.Model):
    UNIT_CHOICES = [
        ('L', 'Litre'),
        ('ML', 'Millilitre'),
        ('G', 'Gram'),
        ('MG', 'Milligram'),
    ]

    name = models.CharField(max_length=100)
    quantity_of_bottles = models.PositiveIntegerField()
    quantity = models.DecimalField(max_digits=10, decimal_places=2)  # per bottle
    unit = models.CharField(max_length=2, choices=UNIT_CHOICES, default='L')
    minimum_quantity = models.DecimalField(max_digits=10, decimal_places=2, default=500)  # in base unit (ML or MG)

    def get_total_base_unit(self):
        """
        Returns the total quantity in the base unit:
        - ML for liquid units
        - MG for solid units
        """
        multiplier = {
            'L': 1000,    # 1 L = 1000 ML
            'ML': 1,
            'G': 1000,    # 1 G = 1000 MG
            'MG': 1
        }.get(self.unit, 1)

        return self.quantity_of_bottles * self.quantity * multiplier

    def get_unit_label(self):
        return dict(self.UNIT_CHOICES).get(self.unit, self.unit)

    def __str__(self):
        return self.name
class LabEquipment(models.Model):
    name = models.CharField(max_length=100)  # Pipette, Rod, Beaker...
    quantity = models.PositiveIntegerField(default=0)  # how many pieces
    minimum_quantity = models.PositiveIntegerField(default=1)  # alert if below

    def __str__(self):
        return f"{self.name} ({self.quantity} nos)"
class ChemistryStack(models.Model):
    serial_no = models.AutoField(primary_key=True)
    year = models.PositiveIntegerField(default=2025)
    bill_number = models.CharField(max_length=50, default='')  # text default
    description_of_machine = models.TextField(default='')
    date_of_purchase = models.DateField(default=date.today)     # valid date default
    supplier_name = models.CharField(max_length=100, default='') 
    rate = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    opening_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    purchase = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def save(self, *args, **kwargs):
        self.total = self.opening_balance + self.purchase
        super().save(*args, **kwargs)
        # Optional MasterStack sync
        MasterStack.objects.create(
            app_name='lenis',
            date=self.date_of_purchase,
            price=self.total,
            description=self.description_of_machine,
            created_by=self.created_by
        )

    def __str__(self):
        return f"{self.serial_no} - {self.description_of_machine} ({self.year})"
class ChemistryEquip(models.Model):
    name = models.CharField(max_length=255)
    count = models.PositiveIntegerField()  # user sets this in form

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

        # If count is less than 6, send email alert
        if self.count < 6:
            send_mail(
                subject=f"Low Stock Alert: {self.name} (Chemistry Lab)",
                message=f"The chemistry equipment '{self.name}' has only {self.count} items left in stock.",
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=['amirasri1835@gmail.com'],  # change to ur mail
                fail_silently=False,
  
            )
class ChemistryRequest(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)  
    equipment_name = models.CharField(max_length=255)   # ✅ store what was requested
    message = models.TextField(blank=True, null=True)   # optional details
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Request by {self.user.username if self.user else 'Anonymous'} - {self.equipment_name}"
class ChemistryDamageReport(models.Model):
    equipment = models.ForeignKey(ChemistryEquip, on_delete=models.CASCADE)
    student_name = models.CharField(max_length=255)
    register_no = models.CharField(max_length=50)
    department = models.CharField(max_length=100)
    year = models.CharField(max_length=20)
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    date_reported = models.DateTimeField(auto_now_add=True)
    paid = models.BooleanField(default=False)
    paid_date = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Damage - {self.equipment.name} ({self.student_name})"