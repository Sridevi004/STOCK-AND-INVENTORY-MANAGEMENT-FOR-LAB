from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login, logout
from .forms import *
from computerlab.forms import ComputerSystemForm
from .models import *
from django.shortcuts import get_object_or_404
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages
from datetime import date, timedelta
from django.utils import timezone
from chemistry.models import ChemistryProduct
from computerlab.models import ComputerSystem
from language.models import LanSystem
from language.forms import LanSystemForm
from lenis.models import LenisSystem
from lenis.forms import LenisSystemForm
from batchmen.models import BatchmenSystem
from batchmen.forms import BatchmenSystemForm
from mechep.models import MechepEquip
from .models import Equip, PhysicsRequest
from .forms import PhysicsRequestForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from .forms import PhysicsStackForm
from .models import PhysicsStack
from core.models import *

def first(request):
    return render(request, 'first.html')

def logi(request):
    context = {
        'error': ''
    }
    if request.method == 'POST':
        user = authenticate(username=request.POST.get('username'), password=request.POST.get('password'))
        if user is not None and user.username.startswith('9210'):
            login(request, user)
            return render(request, "chemistry.html")
        elif user is not None and user.username.startswith('9310'):
            login(request, user)
            equipments = Equip.objects.all()
            return render(request, 'physics.html',{'equipments':equipments})
        elif user is not None and user.username.startswith('9110'):
            login(request, user)
            return render(request, "admin.html")
        elif user is not None and user.username.startswith('9410'):
            login(request, user)
            systems = ComputerSystem.objects.all()
            labs = Lab.objects.all()  # or fetch only related lab
            return render(request, 'computer_list.html', {
                'systems': systems,
                'labs': labs
            })
        elif user is not None and user.username.startswith('9510'):
            login(request, user)
            lansystems = LanSystem.objects.all()

    # Fetch the "Language Lab" object safely
            try:
                language_lab = Lab.objects.get(name__icontains="Language Lab")
            except Lab.DoesNotExist:
                language_lab = None

            return render(request, 'lan_list.html', {
                'lansystems': lansystems,
                'lab': language_lab,   # pass lab to template
            })          
        elif user is not None and user.username.startswith('9610'):
            login(request, user)
            lensystems = LenisSystem.objects.all()
            return render(request, 'lenis_list.html', {'systems': lensystems})
        elif user is not None and user.username.startswith('9710'):
            batchmen_systems = BatchmenSystem.objects.all()
            return render(request, 'batchmen_view.html', {'systems': batchmen_systems})
        elif user is not None and user.username.startswith('9810'):
            login(request, user)
            mequipments = MechepEquip.objects.all()
            return render(request, 'mechep_view.html', {'equipments': mequipments})

        elif user is not None and user.username.startswith('phy'):
            login(request, user)
            equipments = Equip.objects.all()
            return render(request, "view_equipments.html",{'equipments':equipments})
        elif user is not None and user.username.startswith('che'):
            login(request, user)
            
            return render(request, "button.html")
        elif user is not None and user.username.startswith('den'):
            login(request, user)
            systems = ComputerSystem.objects.all()
            form = ComputerSystemForm()
            return render(request, 'computer_view.html', {'form': form,'systems':systems})
        elif user is not None and user.username.startswith('lan'):
            login(request, user)
            lansystems = LanSystem.objects.all()
            form = LanSystemForm()
            return render(request, 'lan_view.html', {'form': form,'lansystems':lansystems})
        elif user is not None and user.username.startswith('len'):
            login(request, user)
            systems_len = LenisSystem.objects.all()
            form = LenisSystemForm()
            return render(request, 'lenis_view.html', {'form': form, 'systems': systems_len})
        elif user is not None and user.username.startswith('bat'):
            systems_bat = BatchmenSystem.objects.all()
            form = BatchmenSystemForm()
            return render(request, 'batchmen_list.html', {'form': form,'systems': systems_bat})
        elif user is not None and user.username.startswith('mech'):
            login(request, user)
            equipments = MechepEquip.objects.all()
            return render(request, "mechep_view.html", {'equipments': equipments})

        else:
            context['error'] = "Invalid username or password"
    return render(request, 'login.html', context)
def boss_view(request):
    return render(request, "boss.html")
def add_equipment(request):
    if request.method == 'POST':
        form = EquipmentForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            count = form.cleaned_data.get('count')
            expiry_date = form.cleaned_data.get('expiry_date')

            if count is None:
                form.add_error('count', 'Count cannot be empty.')
                return render(request, 'add_equipment.html', {'form': form})

            # Find all existing equipment with this name
            existing_qs = Equip.objects.filter(name=name)

            if existing_qs.exists():
                # Sum counts into the first existing equipment
                equipment = existing_qs.first()
                equipment.count += count
                equipment.expiry_date = expiry_date  # optionally update expiry
                equipment.save()

                # Optional: delete duplicates if more than one exists
                if existing_qs.count() > 1:
                    existing_qs.exclude(id=equipment.id).delete()
            else:
                # Create new equipment
                Equip.objects.create(name=name, count=count, expiry_date=expiry_date)

            return redirect('view_equipments')
        else:
            print("Form not valid:", form.errors)
    else:
        form = EquipmentForm()

    return render(request, 'add_equipment.html', {'form': form})


def display_products(request):
    equipments = Equip.objects.all()
    
    return render(request, 'bossview.html', {'equipments': equipments})

def view_equipments(request):
    equipments = Equip.objects.all()
    today = timezone.now().date()

    

    return render(request, 'view_equipments.html', {'equipments': equipments})

def damage(request, id):
    equipment = get_object_or_404(Equip, id=id)
    if request.method == 'POST':
        equipment.count -= 1
        equipment.save()
        return redirect('view_equipments')
    equipments = Equip.objects.all()
    return render(request, 'view_equipments.html',{'equipments': equipments})
#def delete(request,id):
 #   equipment = get_object_or_404(Equip,id=id)
  #  if request.method =='POST':
   #     equipment.delete()
    #    return redirect('view_equipments')
    #equipments = Equip.objects.all()
    #return render(request, 'view_equipments.html',{'equipments': equipments})

def req(request, id):
    equipment = get_object_or_404(Equip, id=id)

    if request.method == 'POST':
        # Any custom logic (e.g., update status)
        equipment.status = 'Requested'  # if you have a status field
        equipment.save()
        messages.success(request, "Request received and processed successfully.")
        return render(request,'physics.html')

    # Fallback GET request handling
    equipments = Equip.objects.all()
    return render(request, 'view_equipments.html', {'equipments': equipments})

def admin_acknowledgement(request):
    return render(request, 'physics.html')

@login_required
def request_product_email(request, id):
    product = get_object_or_404(Equip, id=id)

    if request.method == 'POST':
        user_info = ""
        if request.user.is_authenticated:
            user_info = f"\n\nRequested by: {request.user.username} ({request.user.email})"

        try:
            # ✅ Send email
            send_mail(
                subject=f"Request for Product: {product.name}",
                message=(
                    f"The user has requested the product:\n\n"
                    f"Name: {product.name}\nCount: {product.count}{user_info}"
                ),
                from_email=settings.EMAIL_HOST_USER,
                recipient_list=['amirasri1835@gmail.com'],  # Amira’s email here
                fail_silently=False,
            )


            # ✅ Convert request.user to your custom User model
            CustomUser = get_user_model()
            custom_user = CustomUser.objects.get(username=request.user.username)

            # ✅ Save to PhysicsRequest model
            PhysicsRequest.objects.create(
                user=custom_user,
                message=f"Requested product: {product.name}"
            )

            messages.success(request, "Request received and processed successfully.")
        except Exception as e:
            messages.error(request, f"Failed to send request email: {e}")

        return redirect('display_products')


def physics_notifications(request):
    notifications = PhysicsRequest.objects.all().order_by('-created_at')
    return render(request, 'physics_notifications.html', {'notifications': notifications})  # if you maintain MasterStack

def stack_form_view(request):
    if request.method == 'POST':
        form = PhysicsStackForm(request.POST)
        if form.is_valid():
            stack = form.save(commit=False)
            stack.created_by = request.user
            stack.save()  # saves to PhysicsStack

            # Save to MasterStack
            MasterStack.objects.create(
                app_name='physics',
                date=stack.date_of_purchase,
                price=stack.total,
                description=stack.description_of_machine,
                created_by=request.user
            )

            return redirect('physics_stack_view')  # redirect to physics stack list page
    else:
        form = PhysicsStackForm()

    return render(request, 'stack_form.html', {'form': form})

def stack_view(request):
    stacks = PhysicsStack.objects.all().order_by('-date_of_purchase')
    return render(request, 'stack_view.html', {'stacks': stacks})
def boss_view(request):
    return render(request, "boss.html")
def back_lookphy(request):
    equipments = Equip.objects.all()
    return render(request, "view_equipments.html",{'equipments':equipments})

# 1. Add Damage Report
def add_damage_report_global(request):
    if request.method == "POST":
        form = DamageReportForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Damage report added successfully!")
            return redirect("damage_report_list")
    else:
        form = DamageReportForm()
    return render(request, "add_damage_report.html", {"form": form})


# 2. View All Damage Reports
def damage_report_list(request):
    reports = DamageReport.objects.all().order_by("-date_reported")
    return render(request, "damage_report_list.html", {"reports": reports})
from django.shortcuts import get_object_or_404, redirect
from .models import DamageReport

def toggle_paid(request, pk):
    report = get_object_or_404(DamageReport, pk=pk)
    report.paid = not report.paid

    # Optional: record paid_date
    if report.paid:
        from django.utils import timezone
        report.paid_date = timezone.now()
    else:
        report.paid_date = None

    report.save()
    return redirect("damage_report_list")
def back(request):
    equipments = Equip.objects.all()
    return render(request, 'physics.html',{'equipments':equipments})