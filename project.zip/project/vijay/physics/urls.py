from django.urls import path
from . import views
urlpatterns = [
    
    path ('', views.first, name='first'),
    path("boss/", views.boss_view, name="boss_view"),
    path('login/',views.logi, name='login'),
    path('addproduct/', views.add_equipment, name='add_equipment'),
    path('products/', views.display_products, name='display_products'), 
    path('view_equipments', views.view_equipments, name='view_equipments'),
    path('damage/<int:id>/',views.damage,name='damage'),
    path('req/<int:id>/', views.req, name='req'),
    path('admin-acknowledgement/', views.admin_acknowledgement, name='admin_acknowledgement'),
    path('request_product_email/<int:id>/', views.request_product_email, name='request_product_email'),
    path('notifications/', views.physics_notifications, name='physics_notifications'),
    path('stack/add/', views.stack_form_view, name='physics_stack_form'),
    path('stack/', views.stack_view, name='physics_stack_view'),
    path('backphy/',views.back_lookphy,name='back_lookphy'),
    path("damage-report/add/", views.add_damage_report_global, name="add_damage_report_global"),
    path("damage-report/list/", views.damage_report_list, name="damage_report_list"),
    path("damage-report/toggle/<int:pk>/", views.toggle_paid, name="toggle_paid"),
    path('back',views.back,name='back'),






]

