from django.db import models
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from datetime import timedelta
from datetime import date
from django.contrib.auth import get_user_model
from core.models import MasterStack
from django.contrib.auth.models import User 

User = get_user_model()

class Equip(models.Model):
    name = models.CharField(max_length=255)
    count = models.PositiveIntegerField()  # user sets this in form

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

        # If count is less than 6, send email alert
        if self.count < 6:
            send_mail(
                subject=f"Low Stock Alert: {self.name}",
                message=f"The equipment '{self.name}' has only {self.count} items left in stock.",
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=['amirasri1835@gmail.com'],
                fail_silently=False,
            )
# models.py

class PhysicsRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')  # ✅ add this
    def __str__(self):
        return f"Request by {self.user.username} on {self.created_at.strftime('%Y-%m-%d')}"
class PhysicsStack(models.Model):
    serial_no = models.AutoField(primary_key=True)
    year = models.PositiveIntegerField(default=2025)
    bill_number = models.CharField(max_length=50, default='')  # text default
    description_of_machine = models.TextField(default='')
    date_of_purchase = models.DateField(default=date.today)     # valid date default
    supplier_name = models.CharField(max_length=100, default='') 
    rate = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    opening_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    purchase = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)

    def save(self, *args, **kwargs):
        self.total = self.opening_balance + self.purchase
        super().save(*args, **kwargs)
        # Optional MasterStack sync
        MasterStack.objects.create(
            app_name='lenis',
            date=self.date_of_purchase,
            price=self.total,
            description=self.description_of_machine,
            created_by=self.created_by
        )

    def __str__(self):
        return f"{self.serial_no} - {self.description_of_machine} ({self.year})"




class DamageReport(models.Model):
    equipment = models.ForeignKey(Equip, on_delete=models.CASCADE, related_name="damage_reports")
    student_name = models.CharField(max_length=100)
    register_number = models.CharField(max_length=20)
    department = models.CharField(max_length=100)
    year = models.CharField(max_length=10)
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # new
    date_reported = models.DateTimeField(auto_now_add=True)
    paid = models.BooleanField(default=False)
    paid_date = models.DateTimeField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if self.paid and self.paid_date is None:
            self.paid_date = timezone.now()
        elif not self.paid:
            self.paid_date = None
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.student_name} - {self.equipment.name}"


