# forms.py
from django import forms
from .models import *
from datetime import date
from .models import PhysicsRequest,PhysicsStack
class EquipmentForm(forms.ModelForm):
    class Meta:
        model = Equip
        fields = ['name', 'count', ]
      
    def clean_expiry_date(self):
        expiry_date = self.cleaned_data.get('expiry_date')
        if expiry_date and expiry_date < date.today():
            raise forms.ValidationError("Expiry date cannot be in the past.")
        return expiry_date
# forms.py


class PhysicsRequestForm(forms.ModelForm):
    class Meta:
        model = PhysicsRequest
        fields = ['message']
        widgets = {
            'message': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Enter your query/request here...'}),
        }
class PhysicsStackForm(forms.ModelForm):
    class Meta:
        model = PhysicsStack
        fields = [
            'year', 'bill_number', 'description_of_machine', 'date_of_purchase',
            'supplier_name', 'rate', 'opening_balance', 'purchase'
        ]
        widgets = {
            'date_of_purchase': forms.DateInput(attrs={'type': 'date'}),
            'description_of_machine': forms.Textarea(attrs={'rows': 3}),
        }
class DamageReportForm(forms.ModelForm):
    class Meta:
        model = DamageReport
        fields = [
            "equipment",
            "student_name",
            "register_number",
            "department",
            "year",
            "amount",
        ]