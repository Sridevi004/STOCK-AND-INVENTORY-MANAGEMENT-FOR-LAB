from django.contrib import admin

# Register your models here.josn serializer restframework restapi crud operation api fletch 
